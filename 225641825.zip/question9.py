def question9_1():
    answer = 'SMC'
    return answer

def question9_2():
    answer = 'Jaccard'
    return answer

def question9_3():
    answer = 'Euclidean'
    return answer 

def question9_4():
    answer = 'Euclidean'
    return answer 

def question9_5():
    answer = 'Cosine Similarity'
    return answer