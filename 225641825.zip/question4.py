def question4_1():
    answer = ['nominal', 'nominal'] 
    return answer

def question4_2():
    answer =  ['ratio', 'ordinal']
    return answer

def question4_3():
    answer = ['ratio', 'ordinal']
    return answer 

def question4_4():
    answer = ['ratio', 'ordinal']
    return answer

def question4_5():
    answer = [' ratio', 'ratio']
    return answer

def question4_6():
    answer = ['ratio', ' ordinal']
    return answer

def question4_7():
    answer = ['ratio', 'interval']
    return answer

def question4_8():
    answer = ['ratio', 'interval']
    return answer
