def question7_1():
    answer = 'increase/decrease'
    return answer

def question7_2():
    answer = 'non-increasing'
    return answer

def question7_3():
    answer = [(0., 4.), 
              (4., 5.), 
              (5., 8.), 
              (8., 'infinity')]
    return answer