def question2_1():
    answer = ['quantitative', 'discrete', 'ratio']
    return answer

def question2_2():
    answer = ['quantitative', 'continuous', 'ratio']
    return answer

def question2_3():
    answer = ['quantitative', 'continuous', 'interval']
    return answer 

def question2_4():
    answer = ['qualitative', 'ordinal', 'discrete']
    return answer

def question2_5():
    answer = ['qualitative', 'nominal', 'discrete']
    return answer
