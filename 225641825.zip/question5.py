def question5_1():
    answer = {
            'bin1': [1,2,3,4,5], 
            'bin2': [6,7,8],
            'bin3': [9]
    }
    return answer

def question5_2():
    answer =  {
        'bin1': [1, 2, 3],
        'bin2': [4, 5, 6],
        'bin3': [7, 8, 9]
    }
    return answer

def question5_3():
    answer = {
        'bin1': [1, 5, 6, 7],
        'bin2': [2, 3, 4],
        'bin3': [8, 9]
    }
    return answer 
