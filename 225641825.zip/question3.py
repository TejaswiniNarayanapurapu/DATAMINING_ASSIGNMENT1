def question3_1():
    answer = ['continuous', 'quantitative', 'interval']
    return answer

def question3_2():
    answer = ['discrete', 'qualitative', 'ordinal']
    return answer

def question3_3():
    answer = ['discrete', 'qualitative', 'nominal']
    return answer 

def question3_4():
    answer = ['continuous', 'quantitative', 'ratio']
    return answer

def question3_5():
    answer = ['discrete', 'qualitative', 'nominal']
    return answer

def question3_6():
    answer = ['continuous', 'qualitative', 'ordinal']
    return answer

def question3_7():
    answer = ['continuous', 'quantitative', 'interval']
    return answer

def question3_8():
    answer = ['discrete', 'qualitative', 'ordinal']
    return answer
