def question6_1():
    answer = {
        'equal_width': ['No change', 3],
        'equal_frequency': ['No change', 3] 
    }
    return answer

def question6_2():
    answer = {
        'equal_width': ['No change', 7],
        'equal_frequency': ['No change', 9]
    }
    return answer

def question6_3():
    answer = {
        'equal_width': ['change', 2],
        'equal_frequency': ['No change', 9]
    }
    return answer 