def question8_1():
    answer = ['x1', 'x2']
    return answer

def question8_2():
    answer = 'equally similar'
    return answer

def question8_3():
    answer = 'equally similar'
    return answer 

def question8_4():
    answer = ['x2', 'y3']
    return answer 