
def print_question(question_dict):
    question = question_dict['Question']
    answer = question_dict['Answer']
    justify = question_dict['Justify']
    print(f"{question=}")
