def question10_1():
    answer = False
    justify = 'Count data may also be influenced by noise, as it has the potential to introduce variability and impact the precision of the counts.'
    return answer

def question10_2():
    answer = False
    justify = 'The correlation between actual values typically falls within the range of -1 to 1 exclusively in the case of linear relationships. Otherwise, it can exhibit variations, suggesting either non-linear associations or the absence of linear correlation.'
    return answer

def question10_3():
    answer = False
    justify = 'Aggregating serves to decrease the dimensionality of a time series by summarizing data across intervals, thereby preserving essential patterns. On the other hand, sampling may overlook crucial details, resulting in a loss of information.'
    return answer

def question10_4():
    answer = True
    justify = 'Noise and outliers can be indistinguishable at times since both exhibit substantial deviations from the anticipated pattern, creating challenges in differentiation under specific circumstances.'
    return answer

def question10_5():
    answer = False
    return answer

def question10_6():
    answer = False
    return answer

def question10_7():
    answer = True
    return answer

def question10_8():
    answer = False
    return answer

def question10_9():
    answer = False
    return answer

def question10_10():
    answer = False
    return answer
